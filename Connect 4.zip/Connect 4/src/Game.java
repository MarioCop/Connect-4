public class Game {

    public static void main(String args[])
    {
        Window window = new Window(); // create initial JFrame
    }

}
